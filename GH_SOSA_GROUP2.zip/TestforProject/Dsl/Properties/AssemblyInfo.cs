#region Using directives

using System;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.ConstrainedExecution;

#endregion

//
// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
//
[assembly: AssemblyTitle(@"")]
[assembly: AssemblyDescription(@"")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany(@"Company")]
[assembly: AssemblyProduct(@"TestforProject")]
[assembly: AssemblyCopyright("")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: System.Resources.NeutralResourcesLanguage("en")]

//
// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
// You can specify all the values or you can default the Revision and Build Numbers 
// by using the '*' as shown below:

[assembly: AssemblyVersion(@"1.0.0.0")]
[assembly: ComVisible(false)]
[assembly: CLSCompliant(true)]
[assembly: ReliabilityContract(Consistency.MayCorruptProcess, Cer.None)]

//
// Make the Dsl project internally visible to the DslPackage assembly
//
[assembly: InternalsVisibleTo(@"Company.TestforProject.DslPackage, PublicKey=00240000048000009400000006020000002400005253413100040000010001008DB338E8CE6D8E5E8C7D2A887385D0056C299657CD6B965652581C3BB4EB3424A18DDE7E5BC3DBA6FADF465A4A0907A216395392EA3AA5B9B06FB1CE3E6EF4274BFF033E5EEE951D79C0ADEA18D92DD66BCEFD6EAF34C272C6DFAB1DB3C4105A8862B2B6F24D69A69E87685F72084E236A8E3C9CA0E9C0269497276CB63041B2")]